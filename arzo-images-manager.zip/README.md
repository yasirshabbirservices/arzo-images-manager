# arzo-images-manager
Register missing images from custom folder with advanced duplicate detection and detailed history tracking
